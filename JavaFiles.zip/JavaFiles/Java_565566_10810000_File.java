package example;

public class Java108 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
