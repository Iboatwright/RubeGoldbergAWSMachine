
public class Java253 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
