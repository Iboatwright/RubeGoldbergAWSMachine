package example;

public class Java100 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
