
public class Java725 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
