package example;

public class Java96 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
