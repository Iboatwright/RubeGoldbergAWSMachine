
public class Java655 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
