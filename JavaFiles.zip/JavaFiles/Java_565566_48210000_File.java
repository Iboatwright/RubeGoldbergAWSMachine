package example;

public class Java482 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
