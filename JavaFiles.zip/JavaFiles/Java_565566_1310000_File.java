
public class Java13 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
