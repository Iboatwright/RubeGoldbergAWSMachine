package example;

public class Java256 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
