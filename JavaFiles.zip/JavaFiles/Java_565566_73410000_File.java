package example;

public class Java734 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
