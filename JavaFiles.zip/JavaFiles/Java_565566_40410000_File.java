package example;

public class Java404 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
