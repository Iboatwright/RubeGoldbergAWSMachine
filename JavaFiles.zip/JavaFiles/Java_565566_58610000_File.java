package example;

public class Java586 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
