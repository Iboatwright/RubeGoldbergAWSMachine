package example;

public class Java632 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
