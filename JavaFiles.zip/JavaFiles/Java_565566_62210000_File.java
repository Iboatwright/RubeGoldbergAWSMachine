package example;

public class Java622 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
