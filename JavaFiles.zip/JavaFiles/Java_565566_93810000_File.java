package example;

public class Java938 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
