package example;

public class Java756 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
