package example;

public class Java852 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
