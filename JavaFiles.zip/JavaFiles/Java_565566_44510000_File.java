
public class Java445 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
