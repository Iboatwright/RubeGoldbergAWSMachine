package example;

public class Java942 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
