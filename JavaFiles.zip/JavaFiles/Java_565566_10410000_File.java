package example;

public class Java104 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
