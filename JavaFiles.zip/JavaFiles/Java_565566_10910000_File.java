
public class Java109 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
