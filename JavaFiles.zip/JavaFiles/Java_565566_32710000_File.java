
public class Java327 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
