package example;

public class Java752 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
