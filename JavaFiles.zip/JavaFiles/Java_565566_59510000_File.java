
public class Java595 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
