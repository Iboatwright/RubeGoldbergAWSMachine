package example;

public class Java842 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
