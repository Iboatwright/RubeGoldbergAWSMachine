package example;

public class Java6 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
