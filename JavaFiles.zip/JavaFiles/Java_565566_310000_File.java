
public class Java3 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
