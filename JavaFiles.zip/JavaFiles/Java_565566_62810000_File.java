package example;

public class Java628 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
