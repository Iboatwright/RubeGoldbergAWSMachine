package example;

public class Java932 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
