package example;

public class Java834 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
