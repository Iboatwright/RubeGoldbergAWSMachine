
public class Java175 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
