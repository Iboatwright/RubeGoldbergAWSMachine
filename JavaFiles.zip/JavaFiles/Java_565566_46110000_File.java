
public class Java461 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
