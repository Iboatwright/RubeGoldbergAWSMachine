package example;

public class Java332 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
