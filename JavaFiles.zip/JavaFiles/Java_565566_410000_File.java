package example;

public class Java4 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
