
public class Java635 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
