package example;

public class Java780 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
