
public class Java561 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
