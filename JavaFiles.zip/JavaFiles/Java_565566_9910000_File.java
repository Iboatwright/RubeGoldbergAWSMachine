
public class Java99 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
