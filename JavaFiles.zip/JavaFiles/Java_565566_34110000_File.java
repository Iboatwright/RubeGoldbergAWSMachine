
public class Java341 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
