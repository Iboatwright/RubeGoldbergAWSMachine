package example;

public class Java638 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
