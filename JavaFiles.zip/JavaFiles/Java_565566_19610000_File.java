package example;

public class Java196 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
