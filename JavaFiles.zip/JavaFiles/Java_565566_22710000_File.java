
public class Java227 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
