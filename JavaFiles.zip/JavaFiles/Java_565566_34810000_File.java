package example;

public class Java348 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
