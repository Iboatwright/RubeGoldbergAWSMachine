package example;

public class Java74 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
