
public class Java855 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
