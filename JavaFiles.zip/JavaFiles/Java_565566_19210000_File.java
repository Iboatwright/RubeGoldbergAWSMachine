package example;

public class Java192 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
