package example;

public class Java356 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
