
public class Java249 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
