package example;

public class Java98 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
