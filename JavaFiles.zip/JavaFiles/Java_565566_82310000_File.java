
public class Java823 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
