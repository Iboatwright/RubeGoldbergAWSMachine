package example;

public class Java926 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
