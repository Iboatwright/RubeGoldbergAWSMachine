package example;

public class Java338 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
