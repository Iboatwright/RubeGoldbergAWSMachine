
public class Java187 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
