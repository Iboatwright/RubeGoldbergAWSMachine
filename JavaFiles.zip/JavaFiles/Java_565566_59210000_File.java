package example;

public class Java592 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
