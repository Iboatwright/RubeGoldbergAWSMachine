package example;

public class Java410 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
