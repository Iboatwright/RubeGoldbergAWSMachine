package example;

public class Java342 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
