
public class Java731 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
