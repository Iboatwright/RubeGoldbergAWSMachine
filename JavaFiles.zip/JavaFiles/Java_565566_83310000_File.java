
public class Java833 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
