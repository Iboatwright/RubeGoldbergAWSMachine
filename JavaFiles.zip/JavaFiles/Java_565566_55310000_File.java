
public class Java553 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
