package example;

public class Java822 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
