package example;

public class Java66 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
