package example;

public class Java170 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
