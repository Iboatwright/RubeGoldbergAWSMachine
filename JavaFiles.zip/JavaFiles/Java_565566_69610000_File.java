package example;

public class Java696 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
