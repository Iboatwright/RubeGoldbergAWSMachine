package example;

public class Java114 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
