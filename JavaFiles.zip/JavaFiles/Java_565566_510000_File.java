
public class Java5 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
