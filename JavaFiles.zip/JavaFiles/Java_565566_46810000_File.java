package example;

public class Java468 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
