package example;

public class Java492 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
