package example;

public class Java88 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
