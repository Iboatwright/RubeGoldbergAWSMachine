
public class Java231 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
