package example;

public class Java184 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
