
public class Java417 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
