
public class Java945 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
