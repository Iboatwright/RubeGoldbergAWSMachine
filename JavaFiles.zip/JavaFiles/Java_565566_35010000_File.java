package example;

public class Java350 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
