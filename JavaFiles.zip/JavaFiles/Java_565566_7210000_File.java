package example;

public class Java72 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
