
public class Java509 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
