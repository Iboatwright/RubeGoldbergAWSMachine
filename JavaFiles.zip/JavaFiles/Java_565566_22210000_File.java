package example;

public class Java222 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
