package example;

public class Java746 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
