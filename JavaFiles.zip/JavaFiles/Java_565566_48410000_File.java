package example;

public class Java484 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
