package example;

public class Java740 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
