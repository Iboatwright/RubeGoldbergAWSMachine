package example;

public class Java354 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
