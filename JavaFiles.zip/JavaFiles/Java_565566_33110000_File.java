
public class Java331 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
