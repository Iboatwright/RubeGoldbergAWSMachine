
public class Java345 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
