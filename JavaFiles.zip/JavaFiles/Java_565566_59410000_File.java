package example;

public class Java594 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
