package example;

public class Java928 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
