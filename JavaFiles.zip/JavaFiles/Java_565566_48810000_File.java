package example;

public class Java488 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
