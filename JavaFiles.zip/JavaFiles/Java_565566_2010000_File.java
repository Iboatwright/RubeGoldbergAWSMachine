package example;

public class Java20 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
