package example;

public class Java830 {

    public static void main(String[] args){
        System.out.println(example);
    }
}
